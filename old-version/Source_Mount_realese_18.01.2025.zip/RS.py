import random
import sys
import os

version_RS = "0.1 beta"

def Random_String():
    n = random.randint(4, 15)
    random_string = (''.join(random.choice("abcdefghijklmnopqrstuvwxyz") for i in range(n)))
    return(random_string)