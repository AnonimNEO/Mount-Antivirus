#Coded by @AnonimNEO
from tkinter import messagebox, simpledialog
import tkinter as tk
import string
import random
import os

from RS import Random_String
from LE import Loging_Error
from confing import *

version_exit = "0.8 ALpha"

global exit_T_log_txt, Random_String, ad, random_string
ad = 0
random_string = ""

#Путь к файлу
dyrachok_path = "C:\\ProgramData\\dyrachok.txt"

try:
    def Check_File():
        if not os.path.exists(dyrachok_path):
            with open(dyrachok_path, 'w') as f:
                pass
        else:
            with open(dyrachok_path, 'r') as f:
                content = f.read()
                if "debil" in content:
                    Random_String()
                    messagebox.showwarning(random_string, "Вы смотрите тикток!\nПрограмма не будет закрыта.")
                    return False
        return True



    def tiktok_Question():
        Random_String()
        if messagebox.askyesno(random_string, "Смотрити ли вы тикток?"):
            with open(dyrachok_path, "a") as f:
                f.write("debil")
            Random_String()
            messagebox.showinfo(random_string, "Вы смотрите тикток!\nПрограмма не будет закрыта.")
            ad = 1
        if ad != 1:
            print("Завершение Программы")
            exit()



    def Math_Window():
        Random_String()
        number_input = tk.simpledialog.askinteger(random_string, f"Введите результат данного примера: √{n} * {n}")

        if number_input == n:
            tiktok_Question()
        else:
            Random_String()
            messagebox.showerror(random_string, "Неправильный ввод капчи.\nПрограмма не будет закрыта.")



    def Captcha_Window():
        Random_String()
        print(n)
        captcha_input = tk.simpledialog.askinteger(random_string, f"Введите число: {n}")
        
        if captcha_input == n:
            Math_Window()
        else:
            Random_String()
            messagebox.showerror(random_string, "Неправильный ввод капчи.\nПрограмма не будет закрыта.")



    def Question():
        if Check_File():
            Random_String()
            if messagebox.askyesno(random_string, "Вы действительно хотите выйти из данного програмного обеспечения?"):
                Captcha_Window()
            else:
                Random_String()
                messagebox.showerror(random_string, "Данное програмное обеспечение не будет закрыто.")



    def Ask_Exit():
        Question()

except Exception as e:
    comment = "Неизвестная ошибочка в компоненте exit_T!"
    print(comment)
    print(str(e))
    Loging_Error(comment, exit_T_log_txt, str(e))