#Coded by @AnonimNEO
from tkinter import ttk, messagebox, simpledialog
from datetime import datetime
import win32com.client
import winreg as reg
import tkinter as tk
import random
import winreg
import os

from LE import Loging_Error, Read_loging_txt
from RS import Random_String
from confing import *

Read_loging_txt()

global version_autorun_master, message, mepr, settings_path, message_txt, AR_log_txt, random_string
version_autorun_master = "1.2 Alpha"
random_string = ""
mepr = 0

def AR():
    try:
        def Save_Settings():
            if not os.path.exists(settings_path):
                os.makedirs(settings_path)
                with open(f"{settings_path}\\{message_txt}", "w") as file:
                    file.write("False")
                print(f"Файл {settings_path}\\{message_txt} создан со значением False")
            if not os.path.isfile(f"{settings_path}\\{message_txt}"):
                with open(f"{settings}\\{message_txt}", "w") as file:
                    file.write("False")
                print(f"Файл {settings_path}\\{message_txt} создан со значением False")
            with open(f"{settings_path}\\{message_txt}", "r") as file:
                message = file.read()
            if message == "True":
                print("1-ая праверка переменной message пройдена")
                mepr = 1
            if message == "False":
                print("2-ая проверка переменной message пройдена")
                mepr = 1
            if mepr == 0:
                message = "False"
                with open(f"{settings_path}\\{message_txt}", "w") as file:
                    file.write("False")
                print(f"Файл {settings_path}\\{message_txt} создан со значением False")



        def Apply_Settings(setting1):
            global message
            message = str(setting1)
            Save_Settings()



        #Получаем Список элементов автозагрузки из папки пользователя
        def Get_Startup_Items():
            startup_folder = os.path.expandvars(r"%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup")
            items = []

            for item in os.listdir(startup_folder):
                item_path = os.path.join(startup_folder, item)
                if os.path.isfile(item_path):
                    items.append((item, "Пользовательская", item_path, "Включена"))

            return items



        #Получаем элементы автозагрузки из реестра
        def Get_Registry_Startup():
            try:
                keys = [
                    r"Software\Microsoft\Windows\CurrentVersion\Run",
                    r"Software\Microsoft\Windows\CurrentVersion\RunOnce",
                ]

                items = []

                try:
                    winlogon_key = r"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon"
                    with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, winlogon_key) as registry_key:
                        shell_value = winreg.QueryValueEx(registry_key, "Shell")[0]
                        userinit_value = winreg.QueryValueEx(registry_key, "Userinit")[0]
                        items.append(("Shell", "Реестр System", winlogon_key, shell_value))
                        items.append(("Userinit", "Реестр System", winlogon_key, userinit_value))
                except FileNotFoundError:
                    comment = "Не Обнаружен Winlogon."
                    print(comment + f"\n {str(e)}")
                    Loging_Error(comment, AR_log_txt, str(e))
                except Exception as e:
                    comment = "Ошибка чтения Winlogon"
                    print(f"{comment}: {str(e)}")
                    Loging_Error(comment, AR_log_txt, str(e))

                for key in keys:
                    try:
                        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, key) as registry_key:
                            for i in range(winreg.QueryInfoKey(registry_key)[1]):
                                name, value, _ = winreg.EnumValue(registry_key, i)
                                items.append((name, "Реестр", key, value))
                    except FileNotFoundError:
                        comment = f"Ключ : {key} не найден."
                        print(comment, str(e))
                        Loging_Error(comment, "AR_log.txt", str(e))
                    except Exception as e:
                        comment = f"Ошибка чтения {key}: {str(e)}"
                        print(comment, str(e))
                        Loging_Error(comment, AR_log_txt, str(e))

                return items

            except Exception as e:
                comment = "Ошибка в функции: Get_Registry_Startup"
                print(comment, str(e))
                Loging_Error(comment, AR_log_txt, str(e))
                return []



        #Получаем Элементы из запланированных задач
        def Get_Scheduled_Tasks():
            scheduler = win32com.client.Dispatch("Schedule.Service")
            scheduler.Connect()

            folders = scheduler.GetFolder('\\').GetTasks(0)
            items = []

            for task in folders:
                items.append((task.Name, "Заплонированая", task.Path))
            
            return items



        #Обновляем Данные в таблице
        def Refresh_Data():
            for row in tree.get_children():
                tree.delete(row)

            startup_items = Get_Startup_Items()
            registry_items = Get_Registry_Startup()
            scheduled_tasks = Get_Scheduled_Tasks()

            #Добавление элементов в таблицу
            for item in startup_items:
                tree.insert("", "end", values=item)
            for item in registry_items:
                tree.insert("", "end", values=item)
            for task in scheduled_tasks:
                tree.insert("", "end", values=task)




        #Удаляем элемент автозагрузки или запланированную задачу
        def Delete_Item(selected_item):
            item_name = tree.item(selected_item, "values")[0]
            item_type = tree.item(selected_item, "values")[1]

            if item_type == "Пользовательская":
                item_path = tree.item(selected_item, "values")[2]
                if os.path.isfile(item_path):
                    os.remove(item_path)
                    if message == "True":
                        messagebox.showinfo("Инфо", f"{item_name} Удалено.")
                else:
                    messagebox.showerror("Эхх", f"Не получилось удалить '{item_name}'.")

            elif item_type == "Заплонированая":
                scheduler = win32com.client.Dispatch("Schedule.Service")
                scheduler.Connect()
                task_folder = scheduler.GetFolder('\\')
                try:
                    task_folder.DeleteTask(tree.item(selected_item, "values")[0], 0)  # Проверка правильности имени задачи
                    if message:
                        messagebox.showinfo("Инфо", f"Задача с именем '{item_name}' удалена.")
                except Exception as e:
                    messagebox.showerror("Эхх", f"Не удалось удалить задачу '{item_name}': {str(e)}.")

            elif item_type == "Реестр":
                registry_path = tree.item(selected_item, "values")[2]
                with winreg.OpenKey(winreg.HKEY_CURRENT_USER if 'HKEY_CURRENT_USER' in registry_path else winreg.HKEY_LOCAL_MACHINE, registry_path, 0, winreg.KEY_SET_VALUE) as registry_key:
                    try:
                        winreg.DeleteValue(registry_key, item_name)
                        if message:
                            messagebox.showinfo("Инфо", f"Элемент реестра '{item_name}' удален.")
                    except FileNotFoundError:
                        messagebox.showerror("Эхх", f"Элемент '{item_name}' не найден в реестре.")
                    except Exception as e:
                        messagebox.showerror("Ошибка", f"Не удалось удалить '{item_name}' из реестра: {str(e)}.")


        #Копируем Путь к элементу автозагрузки в буфер обмена
        def Copy_Path(selected_item):
            item_path = tree.item(selected_item, "values")[2]
            AR.clipboard_clear()
            AR.clipboard_append(item_path)
            if message:
                messagebox.showinfo("Инфо", f"Путь '{item_path}' успешно скопирован в буфер обмена.")



        #Редактируем Элемент реестра
        def Edit_Registry_Item(selected_item):
            item_name = tree.item(selected_item, "values")[0]
            item_type = tree.item(selected_item, "values")[1]
            registry_key = tree.item(selected_item, "values")[2]

            if item_type == "Реестр":
                current_value = tree.item(selected_item, "values")[3]
                new_value = simpledialog.askstring("Изменить значение", f"Текущее значение: {current_value}\nВведите новое значение:")
                if new_value is not None:
                    try:
                        with winreg.OpenKey(winreg.HKEY_CURRENT_USER if 'HKEY_CURRENT_USER' in registry_key else winreg.HKEY_LOCAL_MACHINE, registry_key, 0, winreg.KEY_SET_VALUE) as registry_key:
                            winreg.SetValueEx(registry_key, item_name, 0, winreg.REG_SZ, new_value)
                        if message:
                            messagebox.showinfo("Инфо", f"'{item_name}' изменен на '{new_value}'.")
                    except Exception as e:
                        messagebox.showerror("Ошибка", f"Не удалось изменить '{item_name}': {str(e)}.")



        #Обрабатываем Правый клик и открываем контекстное меню
        def On_Right_Click(event):
            selected_item = tree.selection()
            if not selected_item:
                return

            context_menu = tk.Menu(AR, tearoff=0)
            context_menu.add_command(label="Скопировать путь", command=lambda: Copy_Path(selected_item[0]))
            context_menu.add_command(label="Удалить", command=lambda: Delete_Item(selected_item[0]))

            item_type = tree.item(selected_item, "values")[1]
            if item_type == "Registry item":
                context_menu.add_command(label="Изменить", command=lambda: Edit_Registry_Item(selected_item[0]))

            context_menu.post(event.x_root, event.y_root)



        #О Программе
        def About_Program():
            Random_String()
            messagebox.showinfo(random_string, f"Мастер Управления Автозагрузки {version_autorun_master}\nCreated by NEON Life\nPowered by Departament K\nCoded by @AnonimNEO\nCopyright (c) 2024 - 2025")



        #Окно Настроек
        def Settings():
            AR_settings = tk.Toplevel(AR)
            Random_String()
            AR_settings.title(random_string)

            setting_var_1 = tk.BooleanVar(value=message)
            ttk.Checkbutton(AR_settings, text="Показывать сообщения при действиях", variable=setting_var_1).pack()

            apply_button = ttk.Button(AR_settings, text="Применить", command=lambda: Apply_Settings(setting_var_1.get()))
            apply_button.pack(pady=10)



        #Интерфейс
        AR = tk.Tk()

        Random_String()
        AR.title(random_string)

        style = ttk.Style()
        style.theme_use("clam")

        frame = ttk.Frame(AR)
        frame.pack(padx=10, pady=10, fill='both', expand=True)

        columns = ("Имя задачи", "Тип", "Путь/Значение", "Автозагрузка/Значение")
        tree = ttk.Treeview(frame, columns=columns, show="headings")
        tree.pack(side="left", fill="both", expand=True)

        for col in columns:
            tree.heading(col, text=col)

        scrollbar = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
        scrollbar.pack(side="right", fill="y")

        tree.configure(yscroll=scrollbar.set)

        refresh_button = tk.Button(AR, text="Обновить", command=Refresh_Data)
        refresh_button.pack(pady=10)

        tree.bind("<Button-3>", On_Right_Click)

        about_menu = tk.Menu(AR)
        AR.config(menu=about_menu)
        about_menu.add_command(label="О Программе", command=About_Program)
        about_menu.add_command(label="Настройки", command=Settings)

        Refresh_Data() #Начальное Заполнение данных
        AR.mainloop()



    except Exception as e:
        comment = "В AutoRunMaster возникла неизвестаня ошибка!"
        print(comment, str(e))
        if loging == "1":
            Loging_Error(comment, AR_log_txt, str(e))