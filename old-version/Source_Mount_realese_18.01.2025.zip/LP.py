#Coded by @AnonimNEO
from pystray import MenuItem, Icon
from tkinter import messagebox, Tk
from datetime import datetime
from elevate import elevate
from pygame import mixer
from pathlib import Path
import tkinter as tk
import threading
import pystray
#import GPUtil
import psutil
import time
import sys
import os

elevate()

from RS import Random_String
from LE import Loging_Error
from confing import *
from CC22 import CC22

load_protection_version = "1.8 Pre-Alpha Build 11"

mixer.init()

#Глобальные Переменные
global clyth, time_sleep_to_scan, ultimate_load_cpu, ultimate_load_ram, ultimate_load_network, bad_process, exceptions_proc, message, mepr, LP_log_txt, exception_process_txt, emergency_alert_mp3, settings_path, message_txt, random_string
mepr = 0
random_string = ""

#ВНИМАНИЕ! Если раскоментировать строки для логирования ошибок получения нагрузки на GPU и LAN, то программа бесконечно будет дополнять файл log_LP.txt при это вес будет увеличиватся на (примерно) 10КБ в секунду, так как сканирвоание LAN работает примерно 1 раз из 100, но чаще не работает вовсе!
#ВНИМАНИЕ2! Если раскоментировать строки для полной работы программы (тоесть функции связаные с GPU и LAN), программа не сможет работать адекватно, (лог файл будет увеличиватся ещё больше) + бесконечное открывание и закрывание консолей из-за сканирования GPU

if not os.path.exists(settings_path):
    os.makedirs(settings_path)
    with open(f"{settings_path}\\{message_txt}", "w") as file:
        file.write("False")
    print(f"Файл {settings_path}\\{message_txt} создан со значением False")
if not os.path.isfile(f"{settings_path}\\{message_txt}"):
    with open(f"{settings}\\{message_txt}", "w") as file:
        file.write("False")
    print(f"Файл {settings_path}\\{message_txt} создан со значением False")
with open(f"{settings_path}\\{message_txt}", "r") as file:
    message = file.read()
if message == "False":
    print("Первая проверка переменной message пройдена")
    mepr = 1
if message == "True":
    print("Вторая проверка переменной message пройдена")
    mepr = 1
if mepr == 0 :
    print("Ни одна проверка переменной message не пройдена")
    message = "False"
print(message)



try:
    #Получайем Дополнительный список плохих процессов
    def Load_Bad_Processes():
        global bad_process
        try:
            with open(f"{settings_path}\\{bad_process_txt}", "r") as file:
                bad_process = [line.strip() for line in file.readlines() if line.strip()]
        except Exception as e:
            Loging_Error("Ошибка загрузки списка плохих процессов", "LP_log.txt", str(e))
            with open(f"{settings_path}\\{bad_process_txt}", "w") as file:
                file.write("")
            Load_Bad_Processes()



    #Загрузка Настроек
    def Load_Settings():
        global ultimate_load_cpu, ultimate_load_ram, ultimate_load_network
        cpu_file = f"{settings_path}\\{ultimate_load_cpu_txt}"
        #gpu_file = f"{settings_path}\\{ultimate_load_gpu_txt}"
        ram_file = f"{settings_path}\\{ultimate_load_ram_txt}"
        #lan_file = f"{settings_path}\\{ultimate_load_network_txt}"

        #settings_path.mkdir(exist_ok=True)

        try:
            with open(cpu_file, "r") as file:
                encrypted_cpu = file.read()
                ultimate_load_cpu = float(CC22(encrypted_cpu, -clyth)) #Расшифровка
        except Exception as e:
            #ultimate_load_cpu = 45 #Значение По Умолчанию
            Loging_Error("Ошибка загрузки CPU", LP_log_txt, str(e))

        #try:
            #with open(gpu_file, "r") as file:
                #encrypted_gpu = file.read()
                #ultimate_load_gpu = float(CC22(encrypted_gpu, -clyth)) #Расшифровка
        #except Exception as e:
            #pass
            #ultimate_load_gpu = 45 #Значение По Умолчанию
            #Loging_Error("Ошибка загрузки GPU", LP_log_txt, str(e))

        try:
            with open(ram_file, "r") as file:
                encrypted_ram = file.read()
                ultimate_load_ram = float(CC22(encrypted_ram, -clyth)) #Расшифровка
        except Exception as e:
            #ultimate_load_ram = 45 #Значение По Умолчанию
            Loging_Error("Ошибка загрузки RAM", LP_log_txt, str(e))

        #try:
            #with open(lan_file, "r") as file:
                #encrypted_network = file.read()
                #ultimate_load_network = float(CC22(encrypted_network, -clyth)) #Расшифровка
        #except Exception as e:
            #ultimate_load_lan = 15 #Значение По Умолчанию
            #Loging_Error("Ошибка загрузки LAN", LP_log_txt, str(e))

        Save_Settings()



    #Созранение Настроек
    def Save_Settings():
        cpu_file = f"{settings_path}\\{ultimate_load_cpu_txt}"
        #gpu_file = f"{settings_path}\\{ultimate_load_gpu_txt}"
        ram_file = f"{settings_path}\\{ultimate_load_ram_txt}"
        #lan_file = f"{settings_path}\\{ultimate_load_network_txt}"

        try:
            with open(cpu_file, "w") as file:
                file.write(CC22(str(ultimate_load_cpu), clyth)) #Шифрование
            #with open(gpu_file, "w") as file:
                #file.write(CC2(str(ultimate_load_gpu), clyth)) #Шифрование
            with open(ram_file, "w") as file:
                file.write(CC22(str(ultimate_load_ram), clyth)) #Шифрование
            #with open(lan_file, "w") as file:
                #file.write(CC22(str(ultimate_load_network), clyth)) #Шифрование
        except Exception as e:
            Loging_Error("Ошибка сохранения настроек", LP_log_txt, str(e))

    #Загружаем Настройки
    Load_Settings()



    #Получаем Нагрузку на GPU
    def Get_Gpu_Usage(pid):
        try:
            #gpus = GPUtil.getGPUs() #Получаем список доступных GPU
            #for gpu in gpus:
                #process_list = gpu.processes
                #for process in process_list:
                    #if process["pid"] == pid:
                        #return process["gpu_load"] * 100 #Возвращаем % Загрузки GPU
            return 0 #Если Процесс не найден, возвращаем 0
        except Exception as e:
            #log_to_file(f"Ошибка получения нагрузки на GPU для PID {pid}: {str(e)}")
            return 0 #Возвращаем 0 в случае ошибки



    #Получаем Нагрузку на RAM
    def Get_Ram_Usage(pid):
        try:
            process = psutil.Process(pid)
            return process.memory_percent()
        except Exception as e:
            Loging_Error(f"Ошибка получения нагрузки на RAM для PID {pid}", "LP_log.txt", str(e))
            return 0



    #Получаем Нагрузку на LAN (в байтах)
    def Get_Network_Usage(pid):
        try:
            #process = psutil.Process(pid)
            #net_io = process.io_counters()
            #return net_io.bytes_sent + net_io.bytes_recv #Возвращаем общее количество переданных и полученных байтов
            return 0
        except Exception as e:
            Loging_Error(f"Ошибка получения нагрузки на LAN для PID {pid}", "LP_log.txt", str(e))
            return 0



    #Добавляем Искоючение в переменную
    def Add_Exception(process_name):
        global exceptions_proc
        if process_name not in exceptions_proc:
            exceptions_proc.append(process_name)
            Save_Exceptions()
            Random_String()
            messagebox.showinfo(random_string, f"Процесс {process_name} добавлен в список исключений.")
        else:
            Random_String()
            messagebox.showinfo(random_string, f"Процесс {process_name} уже в списке исключений.")



    #Сохраняем Исключение в базу дыннх
    def Save_Exceptions():
        try:
            with open(f"{settings_path}\\{exception_process_txt}", "w") as file:
                encrypted_exceptions = CC22(', '.join(exceptions_proc), clyth)
                file.write(encrypted_exceptions)
        except Exception as e:
            Loging_Error("Ошибка записи в файл исключений", LP_log_txt, str(e))



    #Читаем и Расшифровываем Файл Исключений
    def Load_Exceptions():
        global exceptions_proc
        try:
            with open(f"{settings_path}\\{exception_process_txt}", "r") as file:
                encrypted_exceptions = file.read()
                decrypted_exceptions = CC22(encrypted_exceptions, -clyth) #Расшифровка
                exceptions_proc = [line.strip() for line in decrypted_exceptions.split(",") if line.strip()]
        except Exception as e:
            Loging_Error("Ошибка загрузки списка исключений", LP_log_txt, str(e))
            Save_Exceptions()



    #Сканируем Процеесы
    def Monitor_Processes():
        for proc in psutil.process_iter(["pid", "name", "cpu_percent"]):
            try:
                if proc.info["name"] in exceptions_proc:
                    continue

                cpu_usage = proc.info["cpu_percent"]
                #gpu_usage = Get_Gpu_Usage(proc.info["pid"])
                ram_usage = Get_Ram_Usage(proc.info["pid"])
                #network_usage = Get_Network_Usage(proc.info["pid"])

                if (cpu_usage > ultimate_load_cpu or
                    #gpu_usage > ultimate_load_gpu or
                    ram_usage > ultimate_load_ram or
                    #network_usage > ultimate_load_network or
                    proc.info["name"] in bad_process):
                    try:
                        proc.suspend()
                        for child in proc.children(recursive=True):
                            child.suspend()
                        Notify_User(proc, is_bad_process=(proc.info["name"] in bad_process))
                    except Exception as e:
                        Loging_Error(f"Ошибка заморозки процесса: {proc.info["name"]}", LP_log_txt, e)
                        mixer.music.load(f"C:\\Windows\\media\\{emergency_alert_mp3}")
                        mixer.music.play(5)
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue



    #Уведомления
    def Notify_User(proc, is_bad_process=False):
        def on_unfreeze():
            try:
                for child in proc.children(recursive=True):
                    child.resume()
                #ЕСЛИ РАСКОМЕНТИОВАТЬ СЛЕДУЮЩИЕ 2 СТРОКИ ПРОГРАММА НЕ СПРОСИТ ПРО ДОБОВЛЕНИЕ ПРОЦЕССА В СПИСОК ИСКЛЮЧЕНИЙ, БАГ!!!
                #if message == True:
                #    messagebox.showinfo("Мечта : Поставить Обогреватель в Морозилку и Посмотреть Кто Кого.", f"Процесс {proc.info['name']} (PID: {proc.info['pid']}) разморожен.")
                proc.resume()
                #Запрос на добавление в исключения
                Random_String()
                add_to_exceptions = messagebox.askyesno(random_string, f"Хотите добавить процесс {proc.info["name"]} (PID: {proc.info['pid']}) в список исключений?(если это был плохой процесс то выбор не на что не влияет.)")
                if add_to_exceptions:
                    Add_Exception(proc.info["name"])
                

            except Exception as e:
                Loging_Error(f"Не удалось разморозить процесс {proc.info["name"]}", LP_log_txt, str(e))
                Random_String()
                messagebox.showerror(random_string, f"Не удалось разморозить процесс {proc.info["name"]}: {str(e)}")

        if is_bad_process:
            Random_String()
            response = messagebox.askyesno(random_string, f"Плохой процесс {proc.info["name"]} (PID: {proc.info["pid"]}) заморожен. Хотите разморозить?")
            mixer.music.load(sound_alert_path)
            mixer.music.play(5)
        else:
            mixer.music.load(sound_alert_path)
            mixer.music.play(5)
            Random_String()
            response = messagebox.askyesno(random_string, f"Процесс {proc.info["name"]} (PID: {proc.info["pid"]}) заморожен. Хотите разморозить?")
        
        if response: #Если пользователь нажал "Да"
            On_Unfreeze()



    Load_Bad_Processes()

    #Работв в фоновом режиме
    def Run_Monitor():
        while True:
            Load_Exceptions()
            Monitor_Processes()
            time.sleep(5)

    if __name__ == "__main__":
        #threading.Thread(target=run_monitor, daemon=True).start()
        Run_Monitor()

except Exception as e:
    comment = "Произошла неизвестаня ошибка в LoadProtectin"
    print(comment, str(e))
    Loging_Error(comment, LP_log_txt, str(e))