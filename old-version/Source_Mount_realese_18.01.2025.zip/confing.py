#Общее количество строчек кода
all_line = 2132

#Глобальные Переменные
settings_path = "settings"
log_path = "log"
message_txt = "message.txt"
loging_txt = "loging.txt"
animation_txt = "animation.txt"
bad_process_txt = "bad_process.txt"
ultimate_load_cpu_txt = "ultimate_load_cpu.txt"
ultimate_load_gpu_txt = "ultimate_load_gpu.txt"
ultimate_load_ram_txt = "ultimate_load_ram.txt"
ultimate_load_lan_txt = "ultimate_load_network.txt"
exception_process_txt = "exception_process.txt"
emergency_alert_mp3 = "emergency_alert.mp3"
restart_windows_bat = "restart_windows.bat"
clear_temp_log = "Clear_Temp_log" 
AR_log_txt = "AR_log.txt"
CC_log_txt = "CC_log.txt"
E_log_txt = "E_log.txt"
exit_T_log_txt = "exit_T_log.txt"
LP_log_txt = "LP_log.txt"
MU_log_txt = "MU_log.txt"
R_log_txt = "R_log.txt"
Run_log_txt = "Run_log.txt"
T_log_txt = "T_log.txt"

#Ключ Шифрования
clyth = 13

#Логирования Ошибок 1-вкл | 0-выкл
loging = "1"

#Звуки
sound_alert_path = "alert.mp3"

#T
#Каталог Компонента LoadProtection
LP_path = "LP.exe"
#Вес Файл Комонента LoadProtection в байтах
LP_size = 10879456

#MU
#Каталог Компонента ExplorerAlgorithm
EA_path = "EA.exe"
#Вес Файл Комонента ExplorerAlgorithm в байтах
EA_size = 1174741
#Каталог Компонента Mini-Word
MW_path = "MW.exe"
#Вес Файл Комонента Mini-Word в байтах
MW_size = 1232085
#Каталог Компонента ProcessManager
PM_path = "PM.exe"
#Вес Файл Комонента ProcessManager в байтах
PM_size = 974848

#AP
version_autorun_master = "1.0 Alpha"
clear_cache_version = "0.5 Beta"
version_file_manager = "2.9 Alpha"
version_exit = "0.3 Beta"
loging_errror_version = "0.3"
load_protection_version = "1.6 Pre-Alpha Build 10"
unlocker_version = "1.2 Pre-Alpha Build 8"
restart_version = "0.6 Pre-Alpha"
run_version = "0.5 Beta"

#AR / LP
#Подробные уведомления в Компонентах AutoRunMaster и LoadProtection
message = False
#Делать ли звук тревоги при обнаружении угроз? True - да | False - нет
alert_sound = True

#R
#Через какую библиотеку выполнить перезагрузку windows
#restart_windows = "win32com.client" #НЕ СТАБИЛЬНО
#restart_windows = "os" #НЕ СТАБИЛЬНО
#restart_windows = "subprocess" #НЕ СТАБИЛЬНО
restart_windows = "bat"
#через сколько секунд выполнить перезагрузку
time_to_restart = 1
#Перезапустить ли ОС? True - да | False - нет
reboot_os = True
#Закрыть ПО принудительно? True - да | False - нет
force_software = True
error = 0

#E
#Имя пользователя по умолчанию при ошибке чтения текущего в Компоненте Explorer
user_name = "Admin"
#Добавить в контекстное меню пункт "Открыть с помощью", в Компоненте Explorer
open_with = 0

#LP
#Значения По Умолчанию
#Время ожидания когда Компонент LoadProtection повторит сканирование
time_sleep_to_scan = 5
#Стандартное значения предельной нагрузки на Процессор
ultimate_load_cpu = 20
#Стандартное значения предельной нагрузки на ВидеоКарту
#ultimate_load_gpu = 45
#Стандартное значения предельной нагрузки на Опреративную память
ultimate_load_ram = 35
#Стандартное значения предельной нагрузки на Интернет
#ultimate_load_lan = 15
#Стандартная база запрещёных процессов по имени
bad_process = ["52.exe", "1488.exe", "stalin.exe", "lenin.exe", "virus.exe", "not_a_virus.exe", "malware.exe", "sas.exe", "ass.exe", "yandex.exe", "y.exe", "ya.exe", "Yandex.exe", "Y.exe", "YA.exe", "VK.exe", "vk.exe", "Vk.exe", "vk_music.exe", "VK_MUSIC.exe", "lox.exe", "syka.exe", "вирус.exe", "не_вирус.exe", "НЕ_ВИРУС.exe", "ВИРУС.exe", "notavirus.exe", "NOTAVIRUS.exe", "NotAVirus.exe", "НеВирус.exe", "vagner.exe", "petya.exe", "a4.exe", "A4.exe", "666.exe", "satana.exe", "Satana.exe", "SATANA.exe", "negr.exe", "Negr.exe", "NEGR.exe", "loh.exe", "Loh.ex", "LOH.exe", "eblan.exe", "Eblan.exe", "EBLAN.exe", "chiledwindows.exe", "Stalin.exe", "STALIN.exe", "Lenin.exe", "LENIN.exe", "putin.exe", "Putin.exe", "PUTIN.exe", "pizda.exe", "Pizda.exe", "PIZDA.exe", "xyina.exe", "Xyina.exe", "XYINA.exe", "amogus.exe", "Amogus.exe", "AMOGUS.exe", "abobus.exe", "Abobus.exe", "ABOBUS.exe", "sex.exe", "Sex.exe", "SEX.exe", "pisun.exe", "Pisun.exe", "PISUN.exe", "bebra.exe", "Bebra.exe", "BEBRA.exe", "xyi.exe", "Xyi.exe", "XYI.exe", "сталин.exe", "ленин.exe", "малварь.exe", "сас.exe", "жопа.exe", "яндекс.exe", "я.exe", "Яндекс.exe", "Я.exe", "ВК.exe", "вк.exe", "Вк.exe", "вк_музыка.exe", "ВК_МУЗЫКА.exe", "лох.exe", "сука.exe", "невирус.exe", "НЕВИРУС.exe", "НеВирус.exe"," вагнер.exe", "петя.exe", "а4.exe", "А4.exe", "сатана.exe", "Сатана.exe", "САТАНА.exe", "негр.exe", "Негр.exe", "НЕГР.exe", "ЛОХ.exe", "Лох.exe", "еблан.exe", "Еблан.exe", "ЕБЛАН.exe", "Сталин.exe", "СТАЛИН.exe", "Ленин.exe", "ЛЕНИН.exe", "путин.exe", "Путин.exe", "ПУТИН.exe", "пизда.exe", "Пизда.exe", "ПИЗДА.exe", "хуйня.exe", "Хуйня.exe", "ХУЙНЯ.exe", "амогус.exe", "Амогус.exe", "АМОГУС.exe", "абобус.exe", "Абобус.exe", "АБОБУС.exe", "секс.exe", "Секс.exe", "СЕКС.exe", "писюн.exe", "Писюн.exe", "ПИСЮН.exe", "бебра.exe", "Бебра.exe", "БЕБРА.exe", "хуй.exe", "Хуй.exe", "ХУЙ.exe"]
#Стандартная Максимальная База Исключений
exceptions_proc = ["System Idle Process", "System.exe", "dwm.exe", "Taskmgr.exe", "mmc.exe", "perfmon.exe", "cmd.exe", "conhost.exe", "pio", "GPU", "explorer.exe", "LP.exe", "smss.exe", "Memory Compression", "Interrupts", "Interrupts", "Registry", "csrss.exe", "wininit.exe", "services.exe", "RuntimeBroker.exe", "InputPersonalization.exe", "ApplicationFrameHost.exe", "WindowsInternal.ComposableShell.Experiences.TextInput.InputApp.exe", "taskhostw.exe", "sihost.exe", "audiodg.exe", "spoolsv.exe", "ctfmon.exe", "SearchIndexer.exe", "SearchFilterHost.exe", "SearchProtocolHost.exe", "SearchProtocolHost.exe", "dllhost.exe", "lsass.exe", "fontdrvhost.exe", "csrss.exe", "winlogon.exe", "fontdrvhost.exe", "powershell.exe", "TiWorker.exe", "regedit.exe"]
#Минимальная База Исключения
#exceptions_proc = ["System Idle Process", "System.exe", "dwm.exe", "Taskmgr.exe", "mmc.exe", "perfmon.exe", "cmd.exe", "conhost.exe", "pio", "GPU", "explorer.exe", "LP.exe", "regedit.exe"]
#Расширенная база исключений
#exceptions_proc = ["System Idle Process", "System.exe", "dwm.exe", "Taskmgr.exe", "mmc.exe", "perfmon.exe", "cmd.exe", "conhost.exe", "pio", "GPU", "explorer.exe", "LP.exe", "smss.exe", "Memory Compression", "Interrupts", "Interrupts", "Registry", "csrss.exe", "wininit.exe", "services.exe", "RuntimeBroker.exe", "InputPersonalization.exe", "ApplicationFrameHost.exe", "WindowsInternal.ComposableShell.Experiences.TextInput.InputApp.exe", "taskhostw.exe", "sihost.exe", "audiodg.exe", "spoolsv.exe", "ctfmon.exe", "SearchIndexer.exe", "SearchFilterHost.exe", "SearchProtocolHost.exe", "SearchProtocolHost.exe", "dllhost.exe", "lsass.exe", "fontdrvhost.exe", "csrss.exe", "winlogon.exe", "fontdrvhost.exe", "chrome.exe", "firefox.exe", "Telegram.exe", "memreduct.exe", "sublime_text.exe", "crash_handler.exe", "plugin_host-3.3.exe", "plugin_host-3.8.exe", "mpv.exe", "LightBulb.exe", "RtkAudUService64.exe", "pythonw.exe", "pythonw.exe", "ProcessHacker.exe", "recorder.exe", "uservice.exe", "UninstallTool.exe", "UninstallToolHelper.exe", "powershell.exe", "Win-RARA.exe", "Everything.exe", "Uninstall.exe", "krita.exe", "python.exe", "qbittorrent.exe", "Dism++x64.exe", "7zFM.exe", "HDSentinel.exe", "HDSCtrl.exe", "HDSAction.exe", "HDSentinelTray.exe", "harddisksentinelupdate.exe", "ACCICONS.EXE", "EXCEL.EXE", "GROOVE.EXE", "INFOPATH.EXE", "GRAPH.EXE", "misc.exe", "MSACCESS.EXE", "MSPUB.EXE", "OIS.EXE", "ONENOTE.EXE", "ONENOTEM.EXE", "OUTLOOK.EXE", "POWERPNT.EXE", "PPTICO.EXE", "protocolhandler.exe", "WINWORD.EXE", "WORDICON.EXE", "XLICONS.EXE", "maintenanceservice.exe", "TakeOwnershipEx.exe", "UltraISO.exe", "unins000.exe", "wmplayer.exe", "updater.exe", "regedit.exe", "py.exe", "pyw.exe", "Defrag.exe", "UserAccountControlSettings.exe", "control.exe", "write.exe", "regedt32.exe", "resmon.exe", "Unlocker.exe", "uninst.exe", "VirtualBox.exe", "blender.exe", "blender-launcher.exe"]