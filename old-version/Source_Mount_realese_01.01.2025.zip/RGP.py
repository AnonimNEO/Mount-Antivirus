#Coded by @AnonimNEO
#version = 0.1 Alpha