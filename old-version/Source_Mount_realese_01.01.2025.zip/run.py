#Coded by @AnonimNEO
#version = 0.3 Alpha
from tkinter import messagebox
from datetime import datetime
import tkinter as tk
import subprocess
import random
import os

from LE import loging_error

def run():
    try:
        def start_file_with_admin(path):
            try:
                #Получаем имя текущего пользователя
                username = os.getlogin()
                print(f"Имя текущего пользователя: {username}")
            except Exception as e:
                print("Не Удалось узнать имя пользователя!")

            #Проверяем Существует ли файл
            if os.path.exists(path):
                try:
                    #Запускаем Файлик от имени администратора
                    subprocess.run(["runas", f"/user:{username}", path])
                except Exception as e:
                    print(f"Ошибка при запуске: {e}")
            else:
                comment = "Файл для запуска не найден!"
                print(comment)
                print(str(e))
                loging_error(comment, "run_log", e)
                

        def set_path(path):
            entry.delete(0, tk.END)
            entry.insert(0, path)

        def on_ok():
            path = entry.get()
            start_file_with_admin(path)

        root = tk.Tk()
        root.title(''.join(random.choice('abcdefghijklmnopqrstuvwxyz') for i in range(10)))
        root.geometry("400x200")
        root.configure(bg="#2E2E2E")

        entry = tk.Entry(root, width=50)
        entry.pack(pady=10)

        ok_button = tk.Button(root, text="ОК", command=on_ok, bg="#444444", fg="white")
        ok_button.pack(pady=10)

        buttons_frame = tk.Frame(root, bg="#2E2E2E")
        buttons_frame.pack(pady=10)

        buttons = {
            "CMD": "C:\\Windows\\System32\\cmd.exe",
            "REGEDIT": "C:\\Windows\\regedit.exe",
            "GPEDIT": "C:\\Windows\\System32\\gpedit.msc",
            "POWERSHELL": "C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
            "EXPLORER": "C:\\Windows\\explorer.exe"
        }

        for text, path in buttons.items():
            button = tk.Button(buttons_frame, text=text, command=lambda p=path: set_path(p), bg="#444444", fg="white")
            button.pack(side=tk.LEFT, padx=5)

        root.bind('<Return>', lambda event: on_ok())
        root.mainloop()

    except Exception as e:
        comment = "в программе run произошла неизвестаня ошибка!"
        print(comment)
        print(str(e))
        loging_error(comment, "run_log.txt", e)