#Coded by @AnonimNEO
from tkinter import ttk, messagebox, Menu, simpledialog, filedialog
from datetime import datetime
import winreg as reg
import tkinter as tk
import subprocess
import random
import shutil
import os

#Импорт других файлов
from E import E
from R import R
from AR import AR
#from RGP import RGP
from CC21 import CC21
#from RISM import RISM
from LE import Loging_Error
from confing import *

global loging, AE_path, AE_size, version, clyth, result, anpr, color_index
unlocker_version = "1.2 Pre-Alpha Build 8"
result = ""
anpr = 0
color_index = 0



def MU():
    try:
        def Animation_Read():
            try:
                if not os.path.exists("settings"):
                    os.makedirs("settings")
                    with open("settings\\animation.txt", "w") as file:
                        file.write("True")
                if not os.path.isfile("settings\\animation.txt"):
                    with open("settings\\animation.txt", "w") as file:
                        file.write("True")
                with open("settings\\animation.txt", "r") as file:
                    global animation
                    animation = file.read()
                    print(f"AAAA {animation}")
                if animation == "False":
                    print("Первая проверка переменной animation пройдена")
                    anpr = 1
                if animation == "True":
                    print("Вторая проверка переменной animation пройдена")
                    anpr = 1
                if anpr == 0 :
                    print("Ни одна проверка переменной animation не пройдена")
                    animation = "False"
                print(animation)
            except FileNotFoundError:
                animation = "False"
                print("error", animation)

        Animation_Read()



        #Открыть С помощью
        def Open_With():
            target_file_path = filedialog.askopenfilename(title="Выберите файл для открытия", filetypes=[("Все файлы", "*.*")])
            if target_file_path and os.path.isfile(target_file_path): #Проверка, что файл выбран и существует
                app_path = filedialog.askopenfilename(title="Выберите программу для открытия файла", filetypes=[("Все файлы", "*.*")])
                if app_path:
                    try:
                        subprocess.Popen([app_path, target_file_path])
                    except Exception as e:
                        messagebox.showerror("Ошибка", f"Не удалось открыть файл с помощью указанной программы:\n{str(e)}")



        def UA():
            RGP()

        def Run_Komponent(file, file_size_o):
            try:
                #Проверяем, существует ли файл
                if not os.path.isfile(file):
                    print("Файл не найден.")
                    return

                #Получаем размер файла в байтах
                file_size = os.path.getsize(file)
                print(f"Размер файла: {file_size} байт")

                #Проверяем размер файла
                if file_size != file_size_o:
                    comment = f"Размер файла {file} не равен {file_size_o} байтам. Программа не будет запущена.\nВОЗМОЖНОЕ УГРОЗА СИСТЕМЕ!"
                    print(comment)
                    if loging == "1":
                        Loging_Error(comment, "MU_log.txt", e)
                    return

                #Запускаем файл (предполагается, что это исполняемый файл)
                if file_size == file_size_o:
                    try:
                        os.startfile(file)
                    except Exception as e:
                        print(f"Ошибка при запуске файла {file} : {e}")

            except Exception as e:
                comment = f"Не удалось запустить файл {file}"
                print(comment)
                if loging == "1":
                    Loging_Error(comment, "MU_log.txt", str(e))



        mount_unlocker = tk.Tk()
        mount_unlocker.title(''.join(random.choice("abcdefghijklmnopqrstuvwxyz") for i in range(10)))

        header_text = " Монтировка Анлокер ++ "
        header_label = tk.Label(mount_unlocker, font=("Arial", 32, "bold"))
        header_label.pack()

        #Каждая буква будет иметь свой цвет из радуги
        rainbow_colors = ["red", "orange", "yellow2", "green", "lightgreen", "blue", "skyblue", "violet"]
        color_index = 0 #Индекс текущего цвета

        def Change_Color():
            global color_index
            color = rainbow_colors[color_index]
            color_index = (color_index + 1) % len(rainbow_colors)
            header_label.config(fg=color)
            mount_unlocker.after(500, Change_Color)

        def Update_Text_Color(text, index, label):
            label.config(text=text[:index], fg=rainbow_colors[index % len(rainbow_colors)])
            mount_unlocker.after(150, Update_Text_Color, text, index+1, label)

        if animation == "True":
            Change_Color()
            Update_Text_Color(header_text, 0, header_label)



        #Скорее всего костыли
        def MW():
            Run_Komponent(MW_path, MW_size)
        def EA():
            Run_Komponent(EA_path, EA_size)
        def PM():
            Run_Komponent(PM_path, PM_size)



        process_manager_button = tk.Button(mount_unlocker, text="Диспетчер процессов", command=PM, font=("Arial", 24))
        process_manager_button.pack()
        if animation == "True":
            Update_Text_Color(process_manager_button.cget("text"), 0, process_manager_button)

        file_maneger_button = tk.Button(mount_unlocker, text="Файловый Менеджер", command=E, font=("Arial", 24))
        file_maneger_button.pack()
        if animation == "True":
            Update_Text_Color(file_maneger_button.cget("text"), 0, file_maneger_button)

        #unlock_button = tk.Button(mount_unlocker, text="Разблокировка всего", command=UA, font=("Arial", 24))
        #unlock_button.pack()
        #if animation == "True":
            #Update_Text_Color(unlock_button.cget("text"), 0, unlock_button)

        autoload_button = tk.Button(mount_unlocker, text="Автозагрузка", command=AR, font=("Arial", 24))
        autoload_button.pack()
        if animation == "True":
            Update_Text_Color(autoload_button.cget("text"), 0, autoload_button)

        copyright_label = tk.Label(mount_unlocker, text="Copyraight (c) 2024 NEON Life", anchor="w")
        copyright_label.pack(side="bottom", anchor="w", padx=10, pady=10)

        about_menu = tk.Menu(mount_unlocker)
        mount_unlocker.config(menu=about_menu)

        #Создание Меню
        main_menu = Menu(mount_unlocker)
        mount_unlocker.config(menu=main_menu)

        #Добавление Пункта "Утилиты"
        utilities_menu = Menu(main_menu, tearoff=0)
        main_menu.add_cascade(label="Утилиты", menu=utilities_menu)
        utilities_menu.add_command(label="Mini-Word", command=MW)
        utilities_menu.add_command(label="Файловый Менеджер Алгоритм", command=EA)
        utilities_menu.add_command(label="Перезапустить ПК", command=R)
        #utilities_menu.add_command(label="Перезапустить ПК в Безопасный Режим", command=RISM)
        utilities_menu.add_command(label="Открыть С Помощью", command=Open_With)

        mount_unlocker.mainloop()
        #mount_unlocker.focus()



    except Exception as e:
        comment = "В программе MountUnlocker возникла неизвестная ошибка!\n"
        print(comment)
        print(str(e))
        if loging == "1":
            Loging_Error(comment, "MU_log.txt", str(e))