from datetime import datetime
import os

loging_error_version = "0.3"

def Loging_Error(comment, log_name, e):
    #Записываем ошибку и время в лог файл
    if not os.path.exists("log"):
        os.makedirs("log")
    if not os.path.exists(f"log\\{log_name}"):
        #Если файл не существует, создаем его
        error_time = datetime.now().strftime("%d-%m-%Y %H:%M:%S")
        with open(f"log\\{log_name}", "w") as file:
            file.write(f"Этот лог файл был создан в {error_time}")
        print(f"Файл log\\{log_name} был создан")
    #Получаем текущее время и дату
    error_time = datetime.now().strftime("%d-%m-%Y %H:%M:%S")
    with open(f"log\\{log_name}", "a") as file:
        file.write(f"\n{error_time} Ошибка: {str(e)}, {comment}")
    return

def Read_loging_txt():
    try:
        lopr = 0
        if not os.path.exists("settings"):
            os.makedirs("settings")
            with open("settings\\loging.txt", "w") as file:
                file.write("1")
        if not os.path.isfile("settings\\loging.txt"):
            with open("settings\\loging.txt", "w") as file:
                file.write("1")
        with open("settings\\loging.txt", 'r') as file:
            loging = file.read().strip()
        if loging == "0":
            lopr = 1
            print("1-ая проверка переменной loging пройдена")
        if loging == "1":
            lopr = 1
            print("2-ая проверка переменной loging пройдена")
        if lopr == 0:
            loging = 1
            with open("settings\\loging.txt", "w") as file:
                file.write("1")
            print("файл settings\\loging.txt создан со значением 1")
    except FileNotFoundError:
        loging = "1"
        return loging