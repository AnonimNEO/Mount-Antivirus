#Coded by @AnonimNEO
#version = 0.1 Alpha
from datetime import datetime
import winreg as reg
import os

from R import R
from LE import loging_error

def RISM():
    try:
        def set_safe_mode_with_cmd():
            try:
                #Открываем Ключ реестра
                key = reg.OpenKey(reg.HKEY_LOCAL_MACHINE, r'SYSTEM\CurrentControlSet\Control\SafeBoot', 0, reg.KEY_SET_VALUE)

                #Создаем Подкаталог для безопасного режима с поддержкой командной строки
                reg.CreateKey(key, 'CommandPrompt')

                #Устанавливаем Значение по умолчанию для безопасного режима с командной строкой
                reg.SetValueEx(key, 'CommandPrompt', 0, reg.REG_SZ, 'cmd.exe')

                #Закрываем Ключ
                reg.CloseKey(key)

                print("Параметры реестра успешно изменены. При следующем запуске система загрузится в безопасном режиме с поддержкой командной строки.")
            except Exception as e:
                print(f"Произошла ошибка: {e}")


            except Exception as e:
                comment = "В Программе RestartInSafeMode проищошла неизвестаня ошибка!"
                print(comment)
                print(str(e))
                loging_error(comment, "lRISM_log.txt", e)

        if __name__ == "__main__":
            set_safe_mode_with_cmd()
            R()

    except Exception as e:
        comment = "В Программе RestartInSafeMode проищошла неизвестаня ошибка!"
        print(comment)
        print(str(e))
        loging_error(comment, "RISM_log.txt", e)