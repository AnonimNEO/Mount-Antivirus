#Coded by @AnonimNEO
from PIL import Image, ImageDraw, ImageFont
from tkinter import messagebox, filedialog
from pystray import MenuItem, Menu
from datetime import datetime
from tkinter import ttk
import winreg as reg
import tkinter as tk
import webbrowser
import threading
import pystray
import random
import sys
import os

#Импорт других файлов
#from SF import SF
from CC import CC
from Run import Run
from MU import MU
from confing import *
from CC21 import CC21
#from TEST import TEST
from exit_T import Ask_Exit
from LE import Loging_Error, Read_loging_txt



#Глобальные Переменные
global version_trey, LP_size, LP_path, clyth
version_trey = "1.0 Pre-Alpha Build 11"
result = ""

try :
    Read_loging_txt()



    #Настройки
    def Settings():
        global message, auto_load, animation, cpu_load, gpu_load, ram_load, lan_load, setting1, setting2, setting3
        setting1 = False
        setting2 = True
        setting3 = True
        message = False
        auto_load = True
        animation = True
        cpu_load = 30
        gpu_load = 20
        ram_load = 20
        lan_load = 10

        def apply_changes():
            global message
            global animation
            global autostart
            global cpu_limit
            #global gpu_limit
            global ram_limit
            #global lan_limit

            cpu_value = int(cpu_entry.get())
            #gpu_value = int(gpu_entry.get())
            ram_value = int(ram_entry.get())
            #lan_value = int(lan_entry.get())

            if cpu_value > 100 or gpu_value > 100 or ram_value > 100 or lan_value > 100:
                cpu_value = cpu_load
                #gpu_value = gpu_load
                ram_value = ram_load
                #lan_value = lan_load

            #Получаем значения галочек:
            message = message_var.get()
            animation = animation_var.get()
            autostart = autostart_var.get()

            message_str = str(message)
            animation_str = str(animation)

            #Шифруем значения
            cpu_str = CC21(str(cpu_value), clyth)
            #gpu_str = CC21(str(gpu_value), clyth)
            ram_str = CC21(str(ram_value), clyth)
            #lan_str = CC21(str(lan_value), clyth)

            #Записываем настройки в файлы
            with open("settings\\message.txt", "w") as f:
                f.write(message_str)
            with open("settings\\animation.txt", "w") as f:
                f.write(animation_str)
            with open("settings\\ultimate_load_cpu.txt", "w") as f:
                f.write(cpu_str)
            #with open("settings\\ultimate_load_gpu.txt", "w") as f:
                #f.write(gpu_str)
            with open("settings\\ultimate_load_ram.txt", "w") as f:
                f.write(ram_str)
            #with open("settings\\ultimate_load_lan.txt", "w") as f:
                #f.write(lan_str)

            def LP_in_auto_run():
                try:
                    program_folder = filedialog.askdirectory(title="Введите каталог в котором устанволена программа")
                    LP_path2 = program_folder + "\LP.exe"
                    #Открываем ключ реестра для записи
                    registry_key = reg.OpenKey(reg.HKEY_CURRENT_USER, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Run", 0, reg.KEY_SET_VALUE)

                    #Получаем текущее значение Userinit
                    current_value = reg.QueryValueEx(registry_key, "Userinit")[0]

                    #Создаем новое значение, добавляя к старому
                    new_value = f"{current_value}, {LP_path2}"

                    #Устанавливаем новое значение
                    reg.SetValueEx(registry_key, "Userinit", 0, reg.REG_SZ, new_value)

                    #Закрываем ключ реестра
                    reg.CloseKey(registry_key)
                    print(f"Значение Userinit успешно изменено на {new_value}")

                except PermissionError:
                    print("Необходимы права администратора для изменения реестра.")
                except Exception as e:
                    print(f"Произошла ошибка: {e}")
                    Loging_Error("", "T_log.txt", str(e))

            print(autostart)
            if autostart == True:
                LP_in_auto_run() 

        settings = tk.Tk()
        settings.title(''.join(random.choice("abcdefghijklmnopqrstuvwxyz") for i in range(10)))

        message_var = tk.BooleanVar(value=True)
        animation_var = tk.BooleanVar(value=False)
        autostart_var = tk.BooleanVar(value=False)

        #Пункты с галочками
        tk.Checkbutton(settings, text="Показывать сообщения", variable=message_var).pack(anchor='w')
        tk.Checkbutton(settings, text="Анимация текста в Анлокере", variable=animation_var).pack(anchor='w')
        tk.Checkbutton(settings, text="Автозапуск Load Protection", variable=autostart_var).pack(anchor='w')

        #Поля ввода
        tk.Label(settings, text="Предельная нагрузка на CPU:").pack()
        cpu_entry = tk.Entry(settings)
        cpu_entry.pack()

        #tk.Label(settings, text="Предельная нагрузка на GPU:").pack()
        #gpu_entry = tk.Entry(settings)
        #gpu_entry.pack()

        tk.Label(settings, text="Предельная нагрузка на RAM:").pack()
        ram_entry = tk.Entry(settings)
        ram_entry.pack()

        #tk.Label(settings, text="Предельная нагрузка на LAN:").pack()
        #lan_entry = tk.Entry(settings)
        #lan_entry.pack()

        #Кнопка Для Применения Настроек
        apply_button = tk.Button(settings, text="Применить Изменения", command=apply_changes)
        apply_button.pack()

        settings.mainloop()
        #settings.focus()



    def LP():
        try:
            #Проверяем, существует ли файл
            if not os.path.isfile(LP_path):
                print("Файл не найден.")
                return

            #Получаем размер файла в байтах
            file_size = os.path.getsize(LP_path)
            print(f"Размер файла: {file_size} байт")

            #Проверяем размер файла
            if file_size != LP_size:
                print(f"Размер файла LP.exe не равен {LP_size} байтам. Программа не будет запущена.")
                print("ВОЗМОЖНОЕ УГРОЗА СИСТЕМЕ!")
                Loging_Error(f"Размер файла LP.exe не равен {LP_size} байтам. Программа не будет запущена.\nВОЗМОЖНОЕ УГРОЗА СИСТЕМЕ!", "log_T.txt", "")
                return

            #Запускаем файл (предполагается, что это исполняемый файл)
            if file_size == LP_size:
                try:
                    os.startfile("LP.exe")
                except Exception as e:
                    print(f"Ошибка при запуске файла: {str(e)}")
                    Loging_Error("Ошибка при запуске файла:", "T_log.txt", str(e))

        except Exception as e:
            print(f"Произошла ошибка: {str(e)}")
            Loging_Error(" ", "T_log.txt", str(e))



    def About_Program():
        about_window = tk.Toplevel()
        about_window.title(''.join(random.choice("abcdefghijklmnopqrstuvwxyz") for i in range(10)))

        about_text = f"Антивирус Монтировка\nВытащит любой гвоздь из крышки гроба вашего ПК!(как минимум попытается)\nCreated by NEON Life\nPowered by Departament K\nCoded by @AnonimNEO, Всего строчек кода :{all_line}\nПрограмисты/Задумщики/Художники/Тестировщики : @AnonimNEO\nВерсии Компонентов : \nМастер Автозагрузки : {version_autorun_master}\nОчистка Кэша : {clear_cache_version}\nФайловый Менеджер : {version_file_manager}\nВыход из программы : {version_exit}\nЛогирование Ошибок : {loging_errror_version}\nЗащита Нагрузки : {load_protection_version}\nАнлокер : {unlocker_version}\nПерезапуск : {restart_version}\nЗапуск : {run_version}\nИконка в Трее : {version_trey}\nПоддержать нас можно перейдя по этой ссылке и заплатив \nна 2 банки сгущёнки : https://www.donationalerts.com/r/anonimneo\n\nCopyright NEON Life (c) 2024 - 2025"

        about_label = tk.Label(about_window, text=about_text, padx=20, pady=20, font=("ComicSans", 18))
        about_label.pack()

        def open_donathenalerts_link(event):
            webbrowser.open_new("https://www.donationalerts.com/r/anonimneo")

        about_label.bind("<Button-1>", open_donathenalerts_link)
        #about_label.config(cursor="hand2")

        about_window.mainloop()



    #Создание Иконки
    def Create_Image(width, height):
        #Создаем Изображение
        image = Image.new("RGB", (width, height), (255, 255, 255))
        dc = ImageDraw.Draw(image)

        #Рисуем Синий Квадрат
        dc.rectangle(
            (width // 2 - 10, height // 2 - 10, width // 2 + 10, height // 2 + 10),
            fill=(0, 0, 255)
        )

        #Задаем Шрифт и размер текста
        try:
            font = ImageFont.truetype("arial.ttf", 24)
        except IOError:
            font = ImageFont.load_default()

        #Рисуем Красный Смайлик
        text = "=]"
        text_bbox = dc.textbbox((0, 0), text, font=font)
        text_width = text_bbox[2] - text_bbox[0]
        text_height = text_bbox[3] - text_bbox[1]
        
        text_position = (width // 2 - text_width // 2, height // 2 - text_height // 2)
        dc.text(text_position, text, fill=(255, 0, 0), font=font)

        return image

    #Запуск Иконки
    def Start_Icon(icon):
        icon.visible = True



    #Меню По ПКМ
    image = Create_Image(20, 20)
    menu = Menu(
        MenuItem("Открыть Монтировка Анлокер", MU),
        MenuItem("Запустить Load Protection", LP),
        MenuItem("Запустить Очистку Temp", CC),
        #MenuItem("Запустить Сканер ОС", SF),
        #MenuItem("Сделать Бэкап Файлов ОС", create_backup),
        MenuItem("Запустить От Имени Админа", Run),
        MenuItem("О Программе", About_Program),
        MenuItem("Настройки", Settings),
        #MenuItem("ТЕСТ", TEST),
        MenuItem("Выход", Ask_Exit)
    )

    icon = pystray.Icon("MULTIVAC_ICON", image, "MULTIVAC", menu)
    icon.run(Start_Icon)

    #Запускаем Иконку в отдельном потоке
    threading.Thread(target=run_tray_icon).start()



except KeyboardInterrupt:
    comment = "В программе возникла неизвестаня ошибка!"
    print(comment, str(e))
    Loging_Error(comment, "T_log.txt", str(e))