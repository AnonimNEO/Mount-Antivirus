#Coded by @AnonimNEO
#version = 0.2 beta
def SF():
    try:
        import os
        import shutil
        from datetime import datetime

        #Чтение Файла scna_file_os.txt
        with open("settings\\scan_file_os.txt", "r") as file:
            lines = file.readlines()

        #Создание Списка файлов для сканирования
        files_to_scan = []
        for line in lines:
            path, should_exist = line.strip().split(' ')
            files_to_scan.append((path, should_exist))

        log_file = f"log\\scan_file_os_{datetime.now().strftime("%Y%m%d_%H%M%S")}.txt"

        #Сканирование и Обработка файлов
        with open(log_file, "w") as log_file:
            for path, should_exist in files_to_scan:
                if os.path.exists(path) and should_exist == "False":
                    try:
                        os.remove(path)
                        log_file.write(f"Файл Удалён: {path}\n")
                    except Exception as e:
                        log_file.write(f"Файл не дал себя удалить: {path}. Error: {e}\n")
                elif not os.path.exists(path) and should_exist == "True":
                    try:
                        shutil.copyfile("original_files\\default_file.txt", path)
                        log_file.write(f"Файл скопирован: {path}\n")
                    except Exception as e:
                        log_file.write(f"Ошибка копирования: {path}. Error: {e}\n")

        print(f"Сканирование завершено. Лог сохранён в: {log_filename}")

    except Exception as e:
        #Записываем ошибку и время в лог файл
        if not os.path.exists("log"):
            os.makedirs("log")
        if not os.path.exists("log\\log_CF.txt"):
            #Если файл не существует, создаем его
            error_time = datetime.now().strftime("%d-%m-%Y %H:%M:%S")
            with open("log\\log_CF.txt", "w") as file:
                file.write(f"Этот лог файл был создан в {error_time}")
            print(f"Файл log\\log_CF.txt был создан")
        #Получаем текущее время и дату
        error_time = datetime.now().strftime("%d-%m-%Y %H:%M:%S")
        with open("log\\log_CF.txt", "a") as file:
            file.write(f"\n{error_time} Ошибка: {str(e)}")