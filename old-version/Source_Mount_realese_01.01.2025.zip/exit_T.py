#Coded by @AnonimNEO
import tkinter as tk
from tkinter import messagebox
import random
import string
import math

version_exit = "0.3 Beta"

def Ask_Exit():
    random_string = ''.join(random.choices(string.ascii_letters + string.digits, k=8))
    root = tk.Tk()
    #root.withdraw()

    try:
        with open("C:\\ProgramData\\dyrachok.txt", "r") as file:
            debil_ili_ne_debil = file.read()
    except Exception as e:
        with open("C:\\ProgramData\\dyrachok.txt", "w") as file:
            file.write("")
        debil_ili_ne_debil = ""
    
    random_string = ''.join(random.choices(string.ascii_letters + string.digits, k=10))
    if debil_ili_ne_debil == "debil":
        messagebox.askyesno(random_string, "Вы смотрите ТикТок!\nПрограмма не будет закрыта!", icon="warning")
        return  # Прерываем выполнение функции, чтобы окно не появлялось
    
    response = messagebox.askyesno(random_string, "Вы действительно хотите выйти?", icon="warning")
    if response:
        Show_Captcha()
    else:
        root.destroy()



def Exit_Program():
    root.destroy()
    exit()



def Show_tiktok_Question():
    random_string = ''.join(random.choices(string.ascii_letters + string.digits, k=6))
    response = messagebox.askyesno(random_string, "Смотрите ли вы TikTok?")
    if response:
        random_string = ''.join(random.choices(string.ascii_letters + string.digits, k=14))
        messagebox.showinfo(random_string, "Программа не будет закрыта.")
        with open("C:\\ProgramData\\dyrachok.txt", "w") as file:
            file.write("debil")
        exit()  # Завершаем программу
    else:
        Exit_Program()



def Show_Captcha():
    random_string = ''.join(random.choices(string.ascii_letters + string.digits, k=8))
    captcha_window = tk.Toplevel()
    captcha_window.title(random_string)

    random_string = ''.join(random.choices(string.ascii_letters + string.digits, k=6))
    captcha_label = tk.Label(captcha_window, text=f"Введите следующий набор символов: {random_string}")
    captcha_label.pack(pady=10)

    captcha_entry = tk.Entry(captcha_window)
    captcha_entry.pack(pady=5)

    captcha_button = tk.Button(captcha_window, text="Проверить", command=lambda: Check_Captcha(random_string, captcha_entry.get(), captcha_window))
    captcha_button.pack(pady=10)



def Check_Math_Result(expected, user_input, math_window):
    try:
        if float(user_input) == expected:
            math_window.destroy()  # Закрываем окно математической задачи
            Show_tiktok_Question()
        else:
            messagebox.showerror("Ошибка", "Неправильный ввод. Попробуйте снова.")
    except ValueError:
        messagebox.showerror("Ошибка", "Введите числовое значение.")



def Show_Math_Question():
    n = random.randint(1, 10)
    math_window = tk.Toplevel()
    math_label = tk.Label(math_window, text=f"Введите результат данного выражения: √{n} * {n}")
    math_label.pack(pady=10)

    math_entry = tk.Entry(math_window)
    math_entry.pack(pady=5)

    math_button = tk.Button(math_window, text="Проверить", command=lambda: Check_Math_Result(n, math_entry.get(), math_window))
    math_button.pack(pady=10)



def Check_Captcha(expected, user_input, captcha_window):
    if user_input == expected:
        captcha_window.destroy() #Закрываем окно капчи
        Show_Math_Question()
    else:
        messagebox.showerror("Ошибка", "Неправильный ввод капчи. Попробуйте снова.")