def CC2(text, shift, decrypt=False):
    result = ""
    
    #Определяем длины алфавитов
    english_alphabet_length = 26
    russian_alphabet_length = 33
    
    for char in text: #Обработка букв
        if char.isalpha():
            if 'a' <= char <= 'z':  #английская буква (маленькая)
                base = ord('a')
                shifted_char = chr((ord(char) - base + shift) % english_alphabet_length + base)
                result += shifted_char
            elif 'A' <= char <= 'Z':  #английская буква (большая)
                base = ord('A')
                shifted_char = chr((ord(char) - base + shift) % english_alphabet_length + base)
                result += shifted_char
            elif 'а' <= char <= 'я':  #русская буква (маленькая)
                base = ord('а')
                shifted_char = chr((ord(char) - base + shift) % russian_alphabet_length + base)
                result += shifted_char
            elif 'А' <= char <= 'Я':  #русская буква (большая)
                base = ord('А')
                shifted_char = chr((ord(char) - base + shift) % russian_alphabet_length + base)
                result += shifted_char
        elif char.isdigit(): #Обработка чисел
            num = int(char)
            if decrypt:
                #При расшифровке делим
                new_num = num // shift if shift != 0 else num
            else:
                #При шифровке умножаем
                new_num = num * shift
            result += str(new_num)
        else:
            #Если символ не буква и не цифра, добавляем его без изменений
            result += char

    return result