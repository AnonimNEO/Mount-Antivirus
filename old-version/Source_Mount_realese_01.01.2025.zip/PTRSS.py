#Coded by @AnonimNEO
#version = 0.1 Alpha
from LE import loging_error
import subprocess

def PTRSS()
    try:
        def set_group_policy_default():
            try:
                #Пример команды PowerShell для отключения выполнения скриптов
                subprocess.run(["powershell", "-Command", "Set-ExecutionPolicy Restricted"], check=True)

                #Отключения Автоматического Выполнения Программ
                subprocess.run(["powershell", "-Command", 'Set-ItemProperty -Path "HKLM:\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System" -Name "EnableLUA" -Value 0'], check=True)

                #Разрешение Использования Диспетчера Задач
                subprocess.run(["powershell", "-Command", 'Set-ItemProperty -Path "HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System" -Name "DisableTaskMgr" -Value 0'], check=True)

                #Разрешение Использования Редактора Групповых Политик
                subprocess.run(["powershell", "-Command", 'Set-ItemProperty -Path "HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System" -Name "DisableGpedit" -Value 0'], check=True)

                #Разрешение Использования Редактора Реестра
                subprocess.run(["powershell", "-Command", 'Set-ItemProperty -Path "HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System" -Name "DisableRegistryTools" -Value 0'], check=True)
          
            except subprocess.CalledProcessError as e:
                print(f"{e}")
                loging_error("Ошибка в выполнении команд в PermissionToRunStandardSoftware!", "PTRSS_log.txt", e)

        if __name__ == "__main__":
            set_group_policy_default()

    except Exception as e:
        print(f"{e}")
        loging_error("Неизвестаня Ошибка в PermissionToRunStandardSoftware!", "PTRSS_log.txt", e)